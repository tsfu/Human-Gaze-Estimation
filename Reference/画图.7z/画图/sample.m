load c.mat;
load c1.mat;
load c2.mat;
load c3.mat;
load c4.mat;
b=0:10:90;
plot(b,c,'h-g',b,c1,'*-',b,c2,'s-',b,c3,'v-',b,c4,'o-');
legend('LCER','LLC','ALR','Local Region','HOG+SVR');
xlabel('Scaling Ratios(%)')
ylabel('Gaze Average Error (degree)')