load a.mat;
load a1.mat;
load a2.mat;
load a3.mat;
load a4.mat;
b=0:10:90;
plot(b,a,'h-g',b,a1,'*-',b,a2,'s-',b,a3,'v-',b,a4,'o-');
legend('LCER','LLC','ALR','Local Region','HOG+SVR');
xlabel('Pecent Corrupted (%)')
ylabel('Gaze Average Error (degree)')