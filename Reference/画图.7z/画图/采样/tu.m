% load b36.mat;
% load b25.mat
% load b16.mat
% load b9.mat
% load b4.mat
b=0:10:90;
plot(b,b36,'h-g',b,b25,'*-',b,b16,'s-',b,b9,'v-',b,b4,'o-');
legend('36 training samples','25 training samples','16 training samples','9 training samples','4 training samples');
xlabel('Scaling Ratios(%)')
ylabel('Gaze Average Error (degree)')