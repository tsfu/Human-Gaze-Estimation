function F = HPOG(img, cellpw, cellph, nblockw, nblockh,...
    nthet, overlap, isglobalinterpolate, issigned, normmethod)

% F = HPOG_33(img, cellpw, cellph, nblockw, nblockh,
%    nthet, overlap, isglobalinterpolate, issigned, normmethod)
%
% IMG:
%       IMG is the input image.
%
% CELLPW, CELLPH:
%       CELLPW and CELLPH are cell's pixel width and height respectively.
%
% NBLOCKW, NBLCOKH:
%       NBLOCKW and NBLCOKH are block size counted by cells number in x and
%       y directions respectively.
%
% NTHET, ISSIGNED:
%       NTHET is the number of the bins of the histogram of oriented
%       gradient. The histogram of oriented gradient ranges from 0 to pi in
%       'unsigned' condition while to 2*pi in 'signed' condition, which can
%       be specified through setting the value of the variable ISSIGNED by
%       the string 'unsigned' or 'signed'.
%
% OVERLAP:
%       OVERLAP is the overlap proportion of two neighboring block.
%
% ISGLOBALINTERPOLATE:
%       ISGLOBALINTERPOLATE specifies whether the trilinear interpolation
%       is done in a single global 3d histogram of the whole detecting
%       window by the string 'globalinterpolate' or in each local 3d
%       histogram corresponding to respective blocks by the string
%       'localinterpolate' which is in strict accordance with the procedure
%       proposed in Dalal's paper. Interpolating in the whole detecting
%       window requires the block's sliding step to be an integral multiple
%       of cell's width and height because the histogram is fixing before
%       interpolate. In fact here the so called 'global interpolation' is
%       a notation given by myself. at first the spatial interpolation is 
%       done without any relevant to block's slide position, but when I was
%       doing calculation while OVERLAP is 0.75, something occurred and
%       confused me. This let me find that the operation I firstly
%       did is different from which mentioned in Dalal's paper. But this
%       does not mean it is incorrect, so I reserve this. As for name,
%       besides 'global interpolate', any others would be all ok, like 'Lady GaGa' 
%       or what else).
%
% NORMMETHOD��
%       NORMMETHOD is the block histogram normalized method which can be
%       set as one of the following strings:
%               'none', which means non-normalization;
%               'l1', which means L1-norm normalization;
%               'l2', which means L2-norm normalization;
%               'l1sqrt', which means L1-sqrt-norm normalization;
%               'l2hys', which means L2-hys-norm normalization.
% F��
%       F is a row vector storing the final histogram of all of the blocks 
%       one by one in a top-left to bottom-right image scan manner, the
%       cells histogram are stored in the same manner in each block's
%       section of F.
% This code is revised from the HOG code written by timeHandle.
% Note that CELLPW*NBLOCKW and CELLPH*NBLOCKH should be equal to IMG's
% width and height respectively.
% F = HPOG_33(im, 3, 3, 2, 2, 9, 0.5,'localinterpolate', 'unsigned', 'l2hys');


if nargin < 2
    % set default parameters value.
    cellpw = 3;
    cellph = 3;
    nblockw = 2;
    nblockh = 2;
    nthet = 9;
    overlap = 0.5;
    isglobalinterpolate = 'localinterpolate';
    issigned = 'unsigned';
    normmethod = 'l2hys';
else
    if nargin < 10
        error('Input parameters are not enough.');
    end
end

% check parameters's validity.
[M, N, K] = size(img);
% imgN=zeros(M-3,N-1);
% for i=1:M-3
%     for j=1:N-1
%         imgN(i,j)=img(i,j);
%     end
% end
% img=imgN;
% [M, N, K] = size(img);
if mod(M,cellph*nblockh) ~= 0
    warning('IMG''s height should be an integral multiple of CELLPH*NBLOCKH.');
    disp('resizing image...');
    if mod(M,cellph*nblockh)<(cellph*nblockh/2)
        % shunk image
        tmp = mod(M,cellph*nblockh);
        stIdx_m = floor(tmp/2)+1;
        size_tmp_m = floor(M/(cellph*nblockh))*(cellph*nblockh);
        img = img(stIdx_m:(stIdx_m+size_tmp_m-1), :);
    else
        % enlarge image
        size_tmp_m = ceil(M/(cellph*nblockh))*(cellph*nblockh);
        tmp = size_tmp_m-M;
        upRep = floor(tmp/2);
        bottomRep = ceil(tmp/2);
        img = [img(1:upRep, :); img; img((end-bottomRep+1):end, :)];
    end
    
    if mod(N, cellph*nblockh)<(cellph*nblockh/2)
        % shunk image
        tmp = mod(N,cellph*nblockh);
        stIdx_m = floor(tmp/2)+1;
        size_tmp_m = floor(N/(cellph*nblockh))*(cellph*nblockh);
        img = img(:, stIdx_m:(stIdx_m+size_tmp_m-1));
    else
        % enlarge image
        size_tmp_m = ceil(N/(cellph*nblockh))*(cellph*nblockh);
        tmp = size_tmp_m-N;
        upRep = floor(tmp/2);
        bottomRep = ceil(tmp/2);
        img = [img(:, 1:upRep), img, img(:, (end-bottomRep+1):end)];
    end
    [M, N, K] = size(img);
end
if mod(N,cellpw*nblockw) ~= 0
    warning('IMG''s width should be an integral multiple of CELLPW*NBLOCKW.');
    disp('resizing image...')
end

if mod((1-overlap)*cellpw*nblockw, cellpw) ~= 0 ||...
        mod((1-overlap)*cellph*nblockh, cellph) ~= 0
    str1 = 'Incorrect OVERLAP or ISGLOBALINTERPOLATE parameter';
    str2 = ', slide step should be an intergral multiple of cell size';
    error([str1, str2]);
end

% set the standard deviation of gaussian spatial weight window.
delta = cellpw*nblockw * 0.5;

imgN=zeros(M+2,N+2);
for i=2:M+1
    for j=2:N+1
        imgN(i,j)=img(i-1,j-1);
    end
end
img=imgN;


% calculate gradient scale matrix.
hx = [-1,0,1];
hy = -hx';
gradscalx = imfilter(double(img),hx);
gradscaly = imfilter(double(img),hy);
tempA=zeros(M,N);
tempB=zeros(M,N);
tempC=zeros(M,N);
tempD=zeros(M,N);

for i=2:M+1
    for j=2:N+1
        tempA(i-1,j-1)=gradscalx(i-1,j-1)^2+gradscalx(i-1,j)^2+gradscalx(i-1,j+1)^2+gradscalx(i,j-1)^2+gradscalx(i,j)^2+gradscalx(i,j+1)^2+...
            gradscalx(i+1,j-1)^2+gradscalx(i+1,j)^2+gradscalx(i+1,j+1)^2;
        
        tempB(i-1,j-1)=gradscalx(i-1,j-1)*gradscaly(i-1,j-1)+gradscalx(i-1,j)*gradscaly(i-1,j)+gradscalx(i-1,j+1)*gradscaly(i-1,j+1)+gradscalx(i,j-1)*gradscaly(i,j-1)+...
            gradscalx(i,j)*gradscaly(i,j)+gradscalx(i,j+1)*gradscaly(i,j+1)+gradscalx(i+1,j-1)*gradscaly(i+1,j-1)+gradscalx(i+1,j)*gradscaly(i+1,j)+...
        gradscalx(i+1,j+1)*gradscaly(i+1,j+1);
        
         tempD(i-1,j-1)=gradscaly(i-1,j-1)^2+gradscaly(i-1,j)^2+gradscaly(i-1,j+1)^2+gradscaly(i,j-1)^2+gradscaly(i,j)^2+gradscaly(i,j+1)^2+...
            gradscaly(i+1,j-1)^2+gradscaly(i+1,j)^2+gradscaly(i+1,j+1)^2;
    end
end
tempC=tempB;

% temp_matrix=zeros(4,4);
eigvalue1=zeros(M,N);
eigvalue2=zeros(M,N);
eigvector1x=zeros(M,N);
eigvector1y=zeros(M,N);
eigvector2x=zeros(M,N);
eigvector2y=zeros(M,N);
for i=1:M
    for j=1:N
        temp_matrix=[tempA(i,j),tempB(i,j);tempC(i,j),tempD(i,j)];
        [U,S,V]=svd(temp_matrix);
        eigvalue1(i,j)=S(1,1);
        eigvalue2(i,j)=S(2,2);
        eigvector1x(i,j)=U(1,1);
        eigvector1y(i,j)=U(2,1);
        eigvector2x(i,j)=U(1,2);
        eigvector2y(i,j)=U(2,2);
    end
end
gradscal=eigvalue1;
% gradscal=eigvalue2;

% 
% if K > 1
%         maxgrad = sqrt(double(gradscalx.*gradscalx + gradscaly.*gradscaly));
%         [gradscal, gidx] = max(maxgrad,[],3);
%         gxtemp = zeros(M,N);
%         gytemp = gxtemp;
%         for kn = 1:K
%             ttempx = gradscalx(:,:,kn);
%             ttempy = gradscaly(:,:,kn);
%             tmpindex = find(gidx==kn);
%             gxtemp(tmpindex) = ttempx(tmpindex);
%             gytemp(tmpindex) =ttempy(tmpindex);
%         end
%         gradscalx = gxtemp;
%         gradscaly = gytemp;
% else
%     gradscal = sqrt(double(gradscalx.*gradscalx + gradscaly.*gradscaly));
% end


% calculate gradient orientation matrix.
% plus small number for avoiding dividing zero.
gradscalx=eigvector1x;
gradscaly=eigvector1y;
% gradscalx=eigvector2x;
% gradscaly=eigvector2y;
gradscalxplus = gradscalx+ones(size(gradscalx))*0.0001;
gradorient = zeros(M,N);
% unsigned situation: orientation region is 0 to pi.
if strcmp(issigned, 'unsigned') == 1
    gradorient =...
        atan(gradscaly./gradscalxplus);
    gradorient(gradorient<0) = gradorient(gradorient<0)+pi;
    or = 1;
else
    % signed situation: orientation region is 0 to 2*pi.
    if strcmp(issigned, 'signed') == 1
        idx = find(gradscalx >= 0 & gradscaly >= 0);
        gradorient(idx) = atan(gradscaly(idx)./gradscalxplus(idx));
        idx = find(gradscalx < 0);
        gradorient(idx) = atan(gradscaly(idx)./gradscalxplus(idx)) + pi;
        idx = find(gradscalx >= 0 & gradscaly < 0);
        gradorient(idx) = atan(gradscaly(idx)./gradscalxplus(idx)) + 2*pi;
        or = 2;
    else
        error('Incorrect ISSIGNED parameter.');
    end
end

% calculate block slide step.
xbstride = cellpw*nblockw*(1-overlap);
ybstride = cellph*nblockh*(1-overlap);
xbstridend = N - cellpw*nblockw + 1;
ybstridend = M - cellph*nblockh + 1;

% calculate the total blocks number in the window detected, which is
% ntotalbh*ntotalbw.
ntotalbh = ((M-cellph*nblockh)/ybstride)+1;
ntotalbw = ((N-cellpw*nblockw)/xbstride)+1;

% generate the matrix hist3dbig for storing the 3-dimensions histogram. the
% matrix covers the whole image in the 'globalinterpolate' condition or
% covers the local block in the 'localinterpolate' condition. The matrix is
% bigger than the area where it covers by adding additional elements
% (corresponding to the cells) to the surround for calculation convenience.
if strcmp(isglobalinterpolate, 'globalinterpolate') == 1
    ncellx = N / cellpw;
    ncelly = M / cellph;
    hist3dbig = zeros(ncelly+2, ncellx+2, nthet+2);
    F = zeros(1, (M/cellph-1)*(N/cellpw-1)*nblockw*nblockh*nthet);
    glbalinter = 1;
else
    if strcmp(isglobalinterpolate, 'localinterpolate') == 1
        hist3dbig = zeros(nblockh+2, nblockw+2, nthet+2);
        F = zeros(1, ntotalbh*ntotalbw*nblockw*nblockh*nthet);
        glbalinter = 0;
    else
        error('Incorrect ISGLOBALINTERPOLATE parameter.')
    end
end

% generate the matrix for storing histogram of one block;
sF = zeros(1, nblockw*nblockh*nthet);

% generate gaussian spatial weight.
[gaussx, gaussy] = meshgrid(0:(cellpw*nblockw-1), 0:(cellph*nblockh-1));
weight = exp(-((gaussx-(cellpw*nblockw-1)/2)...
    .*(gaussx-(cellpw*nblockw-1)/2)+(gaussy-(cellph*nblockh-1)/2)...
    .*(gaussy-(cellph*nblockh-1)/2))/(delta*delta));

% vote for histogram. there are two situations according to the interpolate
% condition('global' interpolate or local interpolate). The hist3d which is
% generated from the 'bigger' matrix hist3dbig is the final histogram.
if glbalinter == 1
    xbstep = nblockw*cellpw;
    ybstep = nblockh*cellph;
else
    xbstep = xbstride;
    ybstep = ybstride;
end
% block slide loop
for btly = 1:ybstep:ybstridend
    for btlx = 1:xbstep:xbstridend
        for bi = 1:(cellph*nblockh)
            for bj = 1:(cellpw*nblockw)
                
                i = btly + bi - 1;
                j = btlx + bj - 1;
                gaussweight = weight(bi,bj);
                
                gs = gradscal(i,j);
                go = gradorient(i,j);
                
                if glbalinter == 1
                    jorbj = j;
                    iorbi = i;
                else
                    jorbj = bj;
                    iorbi = bi;
                end
                
                % calculate bin index of hist3dbig
                binx1 = floor((jorbj-1+cellpw/2)/cellpw) + 1;
                biny1 = floor((iorbi-1+cellph/2)/cellph) + 1;
                binz1 = floor((go+(or*pi/nthet)/2)/(or*pi/nthet)) + 1;
                
                if gs < 1E-5
                    continue;
                end
                
                binx2 = binx1 + 1;
                biny2 = biny1 + 1;
                binz2 = binz1 + 1;
                
                x1 = (binx1-1.5)*cellpw + 0.5;
                y1 = (biny1-1.5)*cellph + 0.5;
                z1 = (binz1-1.5)*(or*pi/nthet);
                
                % trilinear interpolation.
                hist3dbig(biny1,binx1,binz1) =...
                    hist3dbig(biny1,binx1,binz1) + gs*gaussweight...
                    * (1-(jorbj-x1)/cellpw)*(1-(iorbi-y1)/cellph)...
                    *(1-(go-z1)/(or*pi/nthet));
                hist3dbig(biny1,binx1,binz2) =...
                    hist3dbig(biny1,binx1,binz2) + gs*gaussweight...
                    * (1-(jorbj-x1)/cellpw)*(1-(iorbi-y1)/cellph)...
                    *((go-z1)/(or*pi/nthet));
                hist3dbig(biny2,binx1,binz1) =...
                    hist3dbig(biny2,binx1,binz1) + gs*gaussweight...
                    * (1-(jorbj-x1)/cellpw)*((iorbi-y1)/cellph)...
                    *(1-(go-z1)/(or*pi/nthet));
                hist3dbig(biny2,binx1,binz2) =...
                    hist3dbig(biny2,binx1,binz2) + gs*gaussweight...
                    * (1-(jorbj-x1)/cellpw)*((iorbi-y1)/cellph)...
                    *((go-z1)/(or*pi/nthet));
                hist3dbig(biny1,binx2,binz1) =...
                    hist3dbig(biny1,binx2,binz1) + gs*gaussweight...
                    * ((jorbj-x1)/cellpw)*(1-(iorbi-y1)/cellph)...
                    *(1-(go-z1)/(or*pi/nthet));
                hist3dbig(biny1,binx2,binz2) =...
                    hist3dbig(biny1,binx2,binz2) + gs*gaussweight...
                    * ((jorbj-x1)/cellpw)*(1-(iorbi-y1)/cellph)...
                    *((go-z1)/(or*pi/nthet));
                hist3dbig(biny2,binx2,binz1) =...
                    hist3dbig(biny2,binx2,binz1) + gs*gaussweight...
                    * ((jorbj-x1)/cellpw)*((iorbi-y1)/cellph)...
                    *(1-(go-z1)/(or*pi/nthet));
                hist3dbig(biny2,binx2,binz2) =...
                    hist3dbig(biny2,binx2,binz2) + gs*gaussweight...
                    * ((jorbj-x1)/cellpw)*((iorbi-y1)/cellph)...
                    *((go-z1)/(or*pi/nthet));
            end
        end
        
        % In the local interpolate condition. F is generated in this block 
        % slide loop. hist3dbig should be cleared in each loop.
        if glbalinter == 0
            if or == 2
                hist3dbig(:,:,2) = hist3dbig(:,:,2)...
                    + hist3dbig(:,:,nthet+2);
                hist3dbig(:,:,(nthet+1)) =...
                    hist3dbig(:,:,(nthet+1)) + hist3dbig(:,:,1);
            end
            hist3d = hist3dbig(2:(nblockh+1), 2:(nblockw+1), 2:(nthet+1));
            for ibin = 1:nblockh
                for jbin = 1:nblockw
                    idsF = nthet*((ibin-1)*nblockw+jbin-1)+1;
                    idsF = idsF:(idsF+nthet-1);
                    sF(idsF) = hist3d(ibin,jbin,:);
                end
            end
            iblock = ((btly-1)/ybstride)*ntotalbw +...
                ((btlx-1)/xbstride) + 1;
            idF = (iblock-1)*nblockw*nblockh*nthet+1;
            idF = idF:(idF+nblockw*nblockh*nthet-1);
            F(idF) = sF;
            hist3dbig(:,:,:) = 0;
        end
    end
end

% In the global interpolate condition. F is generated here outside the
% block slide loop 
if glbalinter == 1
    ncellx = N / cellpw;
    ncelly = M / cellph;
    if or == 2
        hist3dbig(:,:,2) = hist3dbig(:,:,2) + hist3dbig(:,:,nthet+2);
        hist3dbig(:,:,(nthet+1)) = hist3dbig(:,:,(nthet+1)) + hist3dbig(:,:,1);
    end
    hist3d = hist3dbig(2:(ncelly+1), 2:(ncellx+1), 2:(nthet+1));
    
    iblock = 1;
    for btly = 1:ybstride:ybstridend
        for btlx = 1:xbstride:xbstridend
            binidx = floor((btlx-1)/cellpw)+1;
            binidy = floor((btly-1)/cellph)+1;
            idF = (iblock-1)*nblockw*nblockh*nthet+1;
            idF = idF:(idF+nblockw*nblockh*nthet-1);
            for ibin = 1:nblockh
                for jbin = 1:nblockw
                    idsF = nthet*((ibin-1)*nblockw+jbin-1)+1;
                    idsF = idsF:(idsF+nthet-1);
                    sF(idsF) = hist3d(binidy+ibin-1, binidx+jbin-1, :);
                end
            end
            F(idF) = sF;
            iblock = iblock + 1;
        end
    end
end

% adjust the negative value caused by accuracy of floating-point
% operations.these value's scale is very small, usually at E-03 magnitude
% while others will be E+02 or E+03 before normalization.
F(F<0) = 0;

% block normalization.
e = 0.001;
l2hysthreshold = 0.2;
fslidestep = nblockw*nblockh*nthet;
switch normmethod
    case 'none'
    case 'l1'
        for fi = 1:fslidestep:size(F,2)
            div = sum(F(fi:(fi+fslidestep-1)));
            F(fi:(fi+fslidestep-1)) = F(fi:(fi+fslidestep-1))/(div+e);
        end
    case 'l1sqrt'
        for fi = 1:fslidestep:size(F,2)
            div = sum(F(fi:(fi+fslidestep-1)));
            F(fi:(fi+fslidestep-1)) = sqrt(F(fi:(fi+fslidestep-1))/(div+e));
        end
    case 'l2'
        for fi = 1:fslidestep:size(F,2)
            sF = F(fi:(fi+fslidestep-1)).*F(fi:(fi+fslidestep-1));
            div = sqrt(sum(sF)+e*e);
            F(fi:(fi+fslidestep-1)) = F(fi:(fi+fslidestep-1))/div;
        end
    case 'l2hys'
        for fi = 1:fslidestep:size(F,2)
            sF = F(fi:(fi+fslidestep-1)).*F(fi:(fi+fslidestep-1));
            div = sqrt(sum(sF)+e*e);
            sF = F(fi:(fi+fslidestep-1))/div;
            sF(sF>l2hysthreshold) = l2hysthreshold;
            div = sqrt(sum(sF.*sF)+e*e);
            F(fi:(fi+fslidestep-1)) = sF/div;
        end
    otherwise
        error('Incorrect NORMMETHOD parameter.');
end
