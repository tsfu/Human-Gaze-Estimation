function [w] =WSRC(A,b,W)

sigma = 1.5;
W = SimilarityMatrix( A , b , sigma ) ;  %��w  ֮��ľ����ϵ
% W = SimilarityMatrix( trnX , tstX ) ;

% classify
param.lambda = 0.001 ; % not more than 20 non-zeros coefficients
%     param.numThreads=2; % number of processors/cores to use; the default choice is -1
% and uses all the cores of the machine
param.mode = 1 ;       % penalized formulation
param.verbose = false ;
%
num=0;
% w=(A'*A)\A'*b;
% while 1
%     weight = (A *w-b).^2;
%     weight = exp(-weight/(1*mean(weight)));  %�õ�p��ֵ
%     w1 = sqrt(weight);                       %sqrt(p)��ֵ
%     tstX=diag(w1)*b;
%     trnX=diag(w1)*A;
tstX=b;
trnX=A;
    w = mexLassoWeighted( tstX , trnX , W , param ) ;
%     num=num+1;
%     if(num>50)
%         break;
%     end
% end
end